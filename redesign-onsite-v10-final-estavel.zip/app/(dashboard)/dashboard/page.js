'use client';

import { useState, useEffect, useCallback } from 'react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';
import FilterBar from '@/components/ui/FilterBar';
import PageHeader from '@/components/ui/PageHeader';
import StatusBadge from '@/components/ui/StatusBadge';
import { formatDate } from '@/lib/utils';

const STATUS_COLORS = {
  completed:       '#000000',
  in_progress:     '#333333',
  abandoned:       '#666666',
  recount_pending: '#999999',
  pending:         '#cccccc',
};

export default function DashboardPage() {
  const [filters, setFilters] = useState({ from: '', to: '', technicianId: '', status: '' });
  const [technicians, setTechnicians] = useState([]);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/technicians').then((r) => r.json()).then(setTechnicians);
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (filters.from) params.set('from', filters.from);
    if (filters.to) params.set('to', filters.to);
    if (filters.technicianId) params.set('technicianId', filters.technicianId);
    const res = await fetch(`/api/dashboard?${params}`);
    const json = await res.json();
    setData(json);
    setLoading(false);
  }, [filters]);

  useEffect(() => { load(); }, [load]);

  const kpis = data?.kpis || {};
  const recent = data?.recent || [];
  const alerts = data?.alerts || [];

  const pieData = [
    { name: 'Concluido',    value: kpis.completed || 0,       color: STATUS_COLORS.completed },
    { name: 'Em Andamento', value: kpis.in_progress || 0,     color: STATUS_COLORS.in_progress },
    { name: 'Abandonado',   value: kpis.abandoned || 0,       color: STATUS_COLORS.abandoned },
    { name: 'Recontagem',   value: kpis.recount_pending || 0, color: STATUS_COLORS.recount_pending },
    { name: 'Pendente',     value: kpis.pending || 0,         color: STATUS_COLORS.pending },
  ].filter((d) => d.value > 0);

  const completionRate = kpis.total > 0 ? Math.round((kpis.completed / kpis.total) * 100) : 0;

  return (
    <div style={{ padding: '2rem', width: '100%' }}>
      <PageHeader
        title="Dashboard"
        subtitle="Visão geral do inventário cíclico de técnicos"
      />

      <FilterBar filters={filters} onChange={setFilters} technicians={technicians} />

      <div style={{ height: '2rem' }} />

      {loading ? (
        <div style={{ textAlign: 'center', padding: '5rem', color: '#000000', fontWeight: '700' }}>Carregando dados...</div>
      ) : (
        <>
          {/* KPIs - Grid Fluido */}
          <div className="grid-fluid" style={{ marginBottom: '2rem' }}>
            <KpiCard label="Total Inventários" value={kpis.total || 0} sub="No período selecionado" />
            <KpiCard label="Concluídos" value={kpis.completed || 0} sub={`${completionRate}% de taxa de sucesso`} />
            <KpiCard label="Em Andamento" value={kpis.in_progress || 0} sub="Execução em tempo real" />
            <KpiCard label="Divergências" value={kpis.abandoned || 0} sub="Requerem atenção imediata" />
          </div>

          {/* Gráficos e Alertas - Grid Fluido */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '1.5rem', marginBottom: '2rem' }}>
            <div className="card">
              <div className="section-title" style={{ marginBottom: '1.5rem' }}>Distribuição de Status</div>
              <div style={{ height: '250px', width: '100%' }}>
                {pieData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={pieData} cx="50%" cy="50%" innerRadius={60} outerRadius={90} paddingAngle={4} dataKey="value">
                        {pieData.map((entry, i) => (
                          <Cell key={i} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{ background: '#ffffff', border: '1px solid #000000', borderRadius: '4px', fontSize: '0.75rem', fontWeight: '700' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#888888', fontWeight: '600' }}>Sem dados para exibir</div>
                )}
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', marginTop: '1rem', justifyContent: 'center' }}>
                {pieData.map((d) => (
                  <div key={d.name} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.7rem', fontWeight: '700', color: '#000000' }}>
                    <span style={{ width: 10, height: 10, borderRadius: '2px', background: d.color }} />
                    {d.name.toUpperCase()}
                  </div>
                ))}
              </div>
            </div>

            <div className="card">
              <div className="section-title" style={{ marginBottom: '1.5rem' }}>Alertas Críticos</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {alerts.length === 0 ? (
                  <div style={{ textAlign: 'center', padding: '3rem', color: '#888888', fontWeight: '600' }}>Nenhum alerta ativo</div>
                ) : (
                  alerts.map((a) => (
                    <div key={a.id} style={{ padding: '1rem', background: '#f9f9f9', border: '1px solid #eeeeee', borderRadius: '6px' }}>
                      <div style={{ fontSize: '0.85rem', fontWeight: '800', color: '#000000' }}>{a.title}</div>
                      <div style={{ fontSize: '0.75rem', color: '#444444', marginTop: '2px', fontWeight: '500' }}>{a.description}</div>
                      <div style={{ fontSize: '0.65rem', color: '#888888', marginTop: '6px', fontWeight: '700' }}>{formatDate(a.created_at)}</div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Tabela Recente - Full Width */}
          <div className="card" style={{ padding: '0', overflow: 'hidden' }}>
            <div style={{ padding: '1.25rem 1.5rem', background: '#f0f0f0', borderBottom: '1px solid #000000' }}>
              <div className="section-title">Atividade Recente</div>
            </div>
            <div className="table-wrapper" style={{ border: 'none' }}>
              <table>
                <thead>
                  <tr>
                    <th>Técnico</th>
                    <th>Região</th>
                    <th>Semana</th>
                    <th>Status</th>
                    <th>Progresso</th>
                    <th>Divergências</th>
                    <th>Início</th>
                  </tr>
                </thead>
                <tbody>
                  {recent.length === 0 ? (
                    <tr><td colSpan={7} style={{ textAlign: 'center', padding: '4rem', fontWeight: '700' }}>Nenhum inventário recente</td></tr>
                  ) : (
                    recent.map((inv) => {
                      const pct = inv.total_items > 0 ? Math.round((inv.counted_items / inv.total_items) * 100) : 0;
                      return (
                        <tr key={inv.id}>
                          <td style={{ fontWeight: '800', color: '#000000' }}>{inv.technicians?.name}</td>
                          <td style={{ fontWeight: '600' }}>{inv.technicians?.region || '—'}</td>
                          <td style={{ fontWeight: '600' }}>{inv.week_ref || '—'}</td>
                          <td><StatusBadge status={inv.status} /></td>
                          <td>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                              <div className="progress-bar" style={{ width: '80px' }}>
                                <div className="progress-fill" style={{ width: `${pct}%` }} />
                              </div>
                              <span style={{ fontSize: '0.75rem', fontWeight: '800' }}>{pct}%</span>
                            </div>
                          </td>
                          <td style={{ fontWeight: '900', color: inv.divergence_count > 0 ? '#000000' : '#888888' }}>
                            {inv.divergence_count}
                          </td>
                          <td style={{ fontSize: '0.75rem', fontWeight: '600' }}>{formatDate(inv.started_at || inv.created_at)}</td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function KpiCard({ label, value, sub }) {
  return (
    <div className="card" style={{ border: '1px solid #000000', background: '#ffffff' }}>
      <div style={{ fontSize: '0.7rem', fontWeight: '800', color: '#333333', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '0.5rem' }}>{label}</div>
      <div style={{ fontSize: '2.25rem', fontWeight: '900', color: '#000000', lineHeight: 1 }}>{value}</div>
      {sub && <div style={{ fontSize: '0.75rem', color: '#666666', fontWeight: '600', marginTop: '0.5rem' }}>{sub}</div>}
    </div>
  );
}
